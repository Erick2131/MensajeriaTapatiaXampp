<?php

// Conectarse a la base de datos (ajusta estos valores según tu configuración)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mensajeriatapatia";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
} 

// Preparar la consulta SQL para obtener los destinatarios
$sql = "SELECT nombre FROM destinatario";

// Ejecutar la consulta
$result = $conn->query($sql);

// Verificar si se encontraron resultados
if ($result->num_rows > 0) {
    // Arreglo para almacenar los nombres de los destinatarios
    $destinatarios = array();
    
    // Iterar sobre los resultados y almacenar los nombres en el arreglo
    while($row = $result->fetch_assoc()) {
        $destinatarios[] = $row["nombre"];
    }
    
    // Devolver los nombres de los destinatarios como JSON
    echo json_encode($destinatarios);
} else {
    // Si no se encontraron resultados, devolver un mensaje de error
    echo "No se encontraron destinatarios";
}

// Cerrar la conexión
$conn->close();

?>
